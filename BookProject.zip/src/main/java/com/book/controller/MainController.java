package com.book.controller;

import java.io.IOException;
import java.security.Provider.Service;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.book.batch.RunTrigger;
import com.book.batch.UpdatesBookSellCountJob;
import com.book.dto.BookDTO;
import com.book.dto.MemberDTO;
import com.book.service.BookService;
import com.employee.dto.EmployeeDTO;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class MainController {
	
		private BookService service;
	
		public MainController(BookService service) {
		    this.service = service;
		    RunTrigger trigger = new RunTrigger("0 0 0 1 1/1 ? *", UpdatesBookSellCountJob.class);
				trigger.triggerJob();
		    System.out.println("trigger");
		  }
		
	
	  @RequestMapping("/")
	  public String index() {
	    System.out.println("BookTest");
	    return "index";
	  }
	  
	  @PostMapping("/login")
	  public String login(String memberId, int memberPasswd, HttpSession session) {
	    System.out.println(memberId + " " + memberPasswd);
	    
	    MemberDTO dto = Service.login(memberId, memberPasswd);
	    
	    session.setAttribute("member", dto);

	    return "redirect:/main";
	  }
	
	  @RequestMapping("/main")
	  public ModelAndView main(ModelAndView mv) {
	    mv.addObject("book", service.selectAllBook());
	    mv.addObject("member", service.selectAllMember());
	    mv.setViewName("main");
	    return mv;
	  }
	  
	  @RequestMapping("/book/insert")
	  public String insert(BookDTO dto, HttpServletResponse response) throws IOException {
	    System.out.println(dto);
		    try {
		    service.insertBook(dto);
		  } catch (Exception e) {
			  String msg = "<script>alert('데이터 등록에 실패하였습니다');location.href='/main';</script>";
			  response.setContentType("text/html; charset=utf-8");
			  response.getWriter().write(msg);
			  return null;
		  }
	    return "redirect:/book_main";
	  }
	  
	  @RequestMapping("/book/update/{isbn}")
	  public ModelAndView updatView(@PathVariable int isbn, ModelAndView mv) {
	    mv.addObject("dto", service.selectBookIsbn(isbn));
	    mv.addObject("member", service.selectAllMember());
	    mv.setViewName("employee_update");
	    return mv;
	  }
	  
	  
	  @RequestMapping("/book/update")
	  public String update(BookDTO dto) {
	    service.updateBook(dto);
	    return "redirect:/main";
	  }
	  
	  
	  @RequestMapping("/book/delete/{isbn}")
	  public String delete(@PathVariable String isbn) {
	    service.deleteBook(isbn);
	    return "redirect:/main";
	  }
	  
	  @RequestMapping("/book/search")
	  public ResponseEntity<String> search(String kind, String search) {
	    System.out.println(kind + " " + search);
	    List<BookDTO> list = service.searchBook(kind, search);
	    return new ResponseEntity(list, HttpStatus.OK);
	  }
	  
	  @RequestMapping("/book/high-update")
	  public ResponseEntity<String> lowUpdate() {
	    service.updateBookSellCount();
	    List<BookDTO> list = service.selectHighBook();
	    return new ResponseEntity(list, HttpStatus.OK);
	  }
	  
	  
	  
}
