package com.book.batch;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.json.JSONArray;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.book.dto.BookDTO;

public class UpdatesBookSellCountJob implements Job {

  @Override
  public void execute(JobExecutionContext context) throws JobExecutionException {
    
	Date date = new Date(Calendar.getInstance().getTimeInMillis());
	SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
	System.out.println(sdf.format(date));
	run();

  }

  public void run(){
    try {
      URL url = new URL("http://localhost:9999/book/high-update");
      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      conn.setRequestMethod("GET");
      if(conn.getResponseCode() == HttpURLConnection.HTTP_OK){
        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String line = "";
        StringBuffer sb = new StringBuffer();
        while((line = br.readLine()) != null){
          sb.append(line);
        }
        JSONArray arr = new JSONArray(sb.toString());
        for(int i = 0; i < arr.length(); i++){
        	System.out.println(
	          arr.getJSONObject(i).getString("isbn") 
	          + "," + arr.getJSONObject(i).getInt("bookName")
	          + "," + arr.getJSONObject(i).getInt("bookWriter")
	          + "," + arr.getJSONObject(i).getString("bookPublisher")
	          + "," + arr.getJSONObject(i).getString("bookMoney")
	          + "," + arr.getJSONObject(i).getString("bookSellCount")
			);

        }
      }

    } catch (IOException e) {
      e.printStackTrace();
    }

  }

  
}
