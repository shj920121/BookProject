package com.book.mapper;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.book.dto.BookDTO;
import com.book.dto.MemberDTO;

@Mapper
public interface BookMapper {

	MemberDTO login(HashMap<String, Object> map);

	List<BookDTO> selectAllBook();

	List<MemberDTO> selectAllMember();

	List<BookDTO> insertBook();

	

	int updateBook(BookDTO dto);

	int selectBookIsbn(int isbn);

	int deleteBook(int isbn);

	public static List<BookDTO> searchBook(String kind, String txt) {
    HashMap<String, Object> map = new HashMap<String, Object>();
    map.put("kind", kind);
    map.put("txt", txt);
    return mapper.searchBook(map);
  }

	List<BookDTO> selectHighBook();

	
	
	
	

  
  
}