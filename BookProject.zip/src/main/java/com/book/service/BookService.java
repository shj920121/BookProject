package com.book.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Service;

import com.book.dto.BookDTO;
import com.book.dto.MemberDTO;
import com.book.mapper.BookMapper;



@Service
public class BookService {
	private BookMapper mapper;
	
	  public BookService(BookMapper mapper) {
		    this.mapper = mapper;
		  }
	
	public MemberDTO login(String memberId, int memberPasswd) {
		
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("memberId", memberId);
		map.put("memberPasswd", memberPasswd);
		return mapper.login(map);	
  }
		public List<BookDTO> selectAllBook() {
			return mapper.selectAllBook();
		}
		
		public List<MemberDTO> selectAllMember() {
			return mapper.selectAllMember();
		}

		public List<BookDTO> insertBook(BookDTO dto) {
			return mapper.insertBook();
			
		}

		public Object selectBookIsbn(int isbn) {
			
			return mapper.selectBookIsbn();
		}

		public int updateBook(BookDTO dto) {
			return mapper.updateBook(dto);
			
		}

		public int deleteBook(int isbn) {
			return mapper.deleteBook(isbn);
			
		}

		public List<BookDTO> searchBook(String kind, String search) {
			
			return mapper.searchBook();
		}

		public void updateBookSellCount() {
			mapper.updateBook();
			
		}

		public List<BookDTO> selectHighBook() {
			
			return mapper.selectHighBook();
		}
		
		
		
	
		
		
  
}

