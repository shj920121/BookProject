package com.book.dto;

import org.apache.ibatis.type.Alias;

@Alias("member")
public class MemberDTO {
		private String memberId;
		private int memberPasswd;
		private String memberName;
		private String memberTel;
		private int memberLisence;
		public MemberDTO() {
			
		}
		public MemberDTO(String memberId, int memberPasswd, String memberName, String memberTel, int memberLisence) {
			super();
			this.memberId = memberId;
			this.memberPasswd = memberPasswd;
			this.memberName = memberName;
			this.memberTel = memberTel;
			this.memberLisence = memberLisence;
		}
		public String getMemberId() {
			return memberId;
		}
		public void setMemberId(String memberId) {
			this.memberId = memberId;
		}
		public int getMemberPasswd() {
			return memberPasswd;
		}
		public void setMemberPasswd(int memberPasswd) {
			this.memberPasswd = memberPasswd;
		}
		public String getMemberName() {
			return memberName;
		}
		public void setMemberName(String memberName) {
			this.memberName = memberName;
		}
		public String getMemberTel() {
			return memberTel;
		}
		public void setMemberTel(String memberTel) {
			this.memberTel = memberTel;
		}
		public int getMemberLisence() {
			return memberLisence;
		}
		public void setMemberLisence(int memberLisence) {
			this.memberLisence = memberLisence;
		}
		@Override
		public String toString() {
			return "MemberDTO [memberId=" + memberId + ", memberPasswd=" + memberPasswd + ", memberName=" + memberName
					+ ", memberTel=" + memberTel + ", memberLisence=" + memberLisence + "]";
		}

		
		
  
}
