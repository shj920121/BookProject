package com.book.dto;

import org.apache.ibatis.type.Alias;

@Alias("book")
public class BookDTO {
	private int isbn;
	private String bookTitle;
	private String bookWriter;
	private String bookPublisher;
	private int bookMoney;
	private int bookSellCount;
	public BookDTO() {
		
	}
	public BookDTO(int isbn, String bookTitle, String bookWriter, String bookPublisher, int bookMoney,
			int bookSellCount) {
		
		this.isbn = isbn;
		this.bookTitle = bookTitle;
		this.bookWriter = bookWriter;
		this.bookPublisher = bookPublisher;
		this.bookMoney = bookMoney;
		this.bookSellCount = bookSellCount;
	}
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public String getBookWriter() {
		return bookWriter;
	}
	public void setBookWriter(String bookWriter) {
		this.bookWriter = bookWriter;
	}
	public String getBookPublisher() {
		return bookPublisher;
	}
	public void setBookPublisher(String bookPublisher) {
		this.bookPublisher = bookPublisher;
	}
	public int getBookMoney() {
		return bookMoney;
	}
	public void setBookMoney(int bookMoney) {
		this.bookMoney = bookMoney;
	}
	public int getBookSellCount() {
		return bookSellCount;
	}
	public void setBookSellCount(int bookSellCount) {
		this.bookSellCount = bookSellCount;
	}
	
	@Override
	public String toString() {
		return "BookDTO [isbn=" + isbn + ", bookTitle=" + bookTitle + ", bookWriter=" + bookWriter + ", bookPublisher="
				+ bookPublisher + ", bookMoney=" + bookMoney + ", bookSellCount=" + bookSellCount + "]";
	}
	
	
	
	
}
